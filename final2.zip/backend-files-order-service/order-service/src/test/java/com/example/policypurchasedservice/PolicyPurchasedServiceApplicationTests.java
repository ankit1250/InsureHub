package com.example.policypurchasedservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest(
	    classes = OrderServiceApplication.class
	)
class PolicyPurchasedServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
