//package com.repo;
//
//import org.springframework.data.repository.CrudRepository;
//import org.springframework.stereotype.Repository;
//
//import com.model.CartEntity;
//
//@Repository
//public interface PolicyRepo extends CrudRepository<CartEntity, Long> {
//
//}
