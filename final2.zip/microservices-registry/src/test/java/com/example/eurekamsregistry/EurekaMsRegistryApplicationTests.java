package com.example.eurekamsregistry;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaMsRegistryApplicationTests {

	@Test
	void contextLoads() {
	}

}
