package com.example.insuranceservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InsuranceServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
